package com.school.bus.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessageSendingOperations;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.school.bus.data.BusRepository;
import com.school.bus.domain.Bus;
import com.school.bus.services.PositionTrackingExternalService;

@Controller
@Transactional
@RequestMapping("/")
public class BusController 
{
	@Autowired
	private BusRepository data;
	
	@Autowired
	private SimpMessageSendingOperations messagingTemplate;
	
	@Autowired
	private PositionTrackingExternalService externalService;

	@RequestMapping(value="/newBus.html",method=RequestMethod.POST)
	public String newBus(Bus bus)
	{
		data.save(bus);
		return "redirect:/website/buses/list.html";
	}
	
	@RequestMapping(value="/deleteBus.html", method=RequestMethod.POST)
	public String deleteBus(@RequestParam Long id)
	{
		data.delete(id);
		return "redirect:/website/buses/list.html";		
	}
	
	@RequestMapping(value="/newBus.html",method=RequestMethod.GET)
	public ModelAndView renderNewBusForm()
	{
		Bus newBus = new Bus();
		return new ModelAndView("newBus","form",newBus);
	} 
	
	@RequestMapping(value="/", method=RequestMethod.GET)	
	public ModelAndView buses()
	{
		List<Bus> allBuses = data.findAll();
		for (Bus next: allBuses)
		{
			Position latest = externalService.getLatestPositionForBusFromRemoteMicroservice(next.getName());
			next.setLat(latest.getLat());
			next.setLongitude(latest.getLongitude());
			next.setLastRecordedPosition(latest.getTimestamp());
		}
		return new ModelAndView("realTimeSchoolBusTracker", "buses", allBuses);
	}
	  
	@RequestMapping(value="/bus/{name}")
	public ModelAndView showBusByName(@PathVariable("name") String name)
	{
		Bus bus = data.findByName(name);
		
		// get the current position for this bus from the microservice
		Position latestPosition = externalService.getLatestPositionForBusFromRemoteMicroservice(name);
		
		// If successful, then update in our database.
		if (latestPosition.isUpToDate())
		{
			bus.setLat(latestPosition.getLat());
			bus.setLongitude(latestPosition.getLongitude());
			bus.setLastRecordedPosition(latestPosition.getTimestamp());
		}
		
		Map<String,Object> model = new HashMap<>();
		model.put("bus", bus);
		model.put("position", latestPosition);
		return new ModelAndView("busInfo", "model",model);
	}
	
    @Scheduled(fixedRate=100)
    public void updatePositions()
    {
    	// get current position for all buses
    	List<Bus> allBuses = data.findAll();
    	for (Bus next: allBuses)
    	{
    		// Only publish 1 in 10 reports - this makes for random updates, each one approx a second apart
    		if (Math.random() < 0.9) continue;
	    	Position latestPosition = externalService.getLatestPositionForBusFromRemoteMicroservice(next.getName());
	    	this.messagingTemplate.convertAndSend("/buspositions/messages", latestPosition);
    	}
    }
}
