package com.school.bus.services;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.school.bus.controllers.Position;

@FeignClient(name="schoolbus-position-tracker")
public interface RemotePositionMicroserviceCalls 
{
	// REST Call
	// /buses/{name}
	@RequestMapping(method=RequestMethod.GET, value="/buses/{name}")
	public Position getLatestPositionForBus(@PathVariable("name") String name);
}
