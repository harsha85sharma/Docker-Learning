package com.school.bus.data;

import org.springframework.data.jpa.repository.JpaRepository;

import com.school.bus.domain.Bus;

public interface BusRepository extends JpaRepository<Bus, Long>
{
	public Bus findByName(String name);
} 
