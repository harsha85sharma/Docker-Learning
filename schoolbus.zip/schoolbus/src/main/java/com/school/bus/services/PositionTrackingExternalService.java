package com.school.bus.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.school.bus.controllers.Position;
import com.school.bus.data.BusRepository;
import com.school.bus.domain.Bus;

@Service 
public class PositionTrackingExternalService 
{
	@Autowired
	private RemotePositionMicroserviceCalls remoteService;
	
	@Autowired 
	private BusRepository repository;
	
	@HystrixCommand(fallbackMethod="handleExternalServiceDown")
	public Position getLatestPositionForBusFromRemoteMicroservice(String name)
	{
		Position response = remoteService.getLatestPositionForBus(name);
		response.setBusName(name);
		response.setUpToDate(true);
		return response;
	}
	
	
	public Position handleExternalServiceDown(String name)
	{
		// Read the last known position for this bus
		Position position = new Position();
		Bus bus = repository.findByName(name);
		position.setLat(bus.getLat());
		position.setLongitude(bus.getLongitude());
		position.setTimestamp(bus.getLastRecordedPosition());
		position.setUpToDate(false);
		return position;
	}
	
}
