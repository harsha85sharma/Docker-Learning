# schoolbus-webapp
A basic web front end for the School Bus Live Tracking system.
